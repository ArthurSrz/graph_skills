"""MCP Wikidata Server - Model Context Protocol server for Wikidata access."""

__version__ = "0.1.0"
__author__ = "MCP Wikidata Team"
__description__ = "Model Context Protocol server for Wikidata access"